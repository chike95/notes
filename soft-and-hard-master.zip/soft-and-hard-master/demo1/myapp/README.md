# README
demo2例程。
```bash
# 安装依赖
npm install
# 运行
npm start
# 访问localhost:8001
# TCP 端口：9002
```