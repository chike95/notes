# README
这是一个WebScoket服务器端简单例程。前端与后端建立WebSocket连接后，通过WebScoket传输随机数到前端，用Echart显示数据。
```bash
# 安装依赖
npm install
# 运行
npm start
# 访问localhost:3000
```